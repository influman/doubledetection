# Installation
Couplage de deux d�tecteurs de mouvements dans un seul d�tecteur virtuel.  
Objectif : limiter les fausses d�tections d'intrusion  
  

### Ajout du p�riph�rique 
Cliquez sur "Configuration" / "Ajouter ou supprimer un p�riph�rique" / "Store eedomus" / "Double D�tection" / "Cr�er"  

![STEP1](https://i.imgur.com/TkR7YAd.png)


*Voici les diff�rents champs � renseigner:*

* [Obligatoire] - Le nom de l'emplacement du 1er d�tecteur  
* [Obligatoire] - Le p�riph�rique 1er D�tecteur de mouvement
* [Obligatoire] - Le nom de l'emplacement du 2nd d�tecteur 
* [Obligatoire] - Le p�riph�rique 2nd D�tecteur de mouvement
  
Un capteur "Double D�tection" sera alors disponible :  

![STEP4](https://i.imgur.com/FPgeWGD.png)

### R�gles

Deux r�gles eedomus sont cr��es pour synchroniser les statuts des 2 d�tecteurs r�els avec les 2 d�tecteurs virtuels cr��s par le plug-in   

![STEP2](https://i.imgur.com/gw0vhEn.png) 

![STEP3](https://i.imgur.com/YpfOs9b.png)

